package com.cloudeai.realnavigationpro;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.webkit.*;
import java.util.*;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private BroadcastReceiver gpsReceiver;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        ArrayList<String> p=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        if(Build.VERSION.SDK_INT>=29 && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.POST_NOTIFICATIONS);
        if(!p.isEmpty() && Build.VERSION.SDK_INT>=23) requestPermissions(p.toArray(new String[0]),7);

        tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS)try{tts.setLanguage(new Locale("si","LK"));}catch(Exception ignored){}});

        web=new WebView(this);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setGeolocationEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback cb){cb.invoke(origin,true,false);}
        });
        web.addJavascriptInterface(new NativeBridge(),"NativeNav");
        setContentView(web);
        if(Build.VERSION.SDK_INT>=23){
            try{
                android.os.PowerManager pm=(android.os.PowerManager)getSystemService(POWER_SERVICE);
                if(!pm.isIgnoringBatteryOptimizations(getPackageName())){
                    Intent bi=new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    bi.setData(Uri.parse("package:"+getPackageName()));
                    startActivity(bi);
                }
            }catch(Exception ignored){}
        }
        web.loadUrl("file:///android_asset/index.html");

        gpsReceiver=new BroadcastReceiver(){
            @Override public void onReceive(Context c,Intent i){
                double lat=i.getDoubleExtra("lat",0),lon=i.getDoubleExtra("lon",0);
                double speed=i.getDoubleExtra("speed",0),bearing=i.getDoubleExtra("bearing",0);
                float acc=i.getFloatExtra("accuracy",0);
                String js="window.onNativeLocation && window.onNativeLocation("+lat+","+lon+","+speed+","+bearing+","+acc+")";
                web.post(()->web.evaluateJavascript(js,null));
            }
        };
        registerReceiver(gpsReceiver,new IntentFilter("REAL_NAV_LOCATION"),Context.RECEIVER_NOT_EXPORTED);
    }

    public class NativeBridge {
        @JavascriptInterface public void speak(String text){if(tts!=null)tts.speak(String.valueOf(text),TextToSpeech.QUEUE_FLUSH,null,"nav");}
        @JavascriptInterface public void startForeground(){startService(new Intent(MainActivity.this,NavigationService.class));}
        @JavascriptInterface public void stopForeground(){stopService(new Intent(MainActivity.this,NavigationService.class));}
    }

    @Override protected void onDestroy(){
        try{unregisterReceiver(gpsReceiver);}catch(Exception ignored){}
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }
}
