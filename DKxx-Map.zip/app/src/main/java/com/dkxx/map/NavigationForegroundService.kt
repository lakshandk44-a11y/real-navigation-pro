package com.dkxx.map

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class NavigationForegroundService : Service() {

    companion object {
        private const val CHANNEL_ID = "dkxx_navigation"
        private const val NOTIFICATION_ID = 77
    }

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "DKxx navigation",
                NotificationManager.IMPORTANCE_LOW
            )
        )
        startForeground(NOTIFICATION_ID, notification("Navigation is active"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val text = intent?.getStringExtra("text") ?: "Navigation is active"
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification(text))
        return START_STICKY
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_map)
            .setContentTitle("DKxx Map")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
            .build()

    override fun onBind(intent: Intent?): IBinder? = null
}
