package com.dkxx.map

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.tomtom.sdk.map.display.ui.MapFragment
import com.tomtom.sdk.map.display.TomTomMap
import com.tomtom.sdk.map.display.route.RouteOptions
import com.tomtom.sdk.map.display.route.Route
import com.tomtom.sdk.location.GeoPoint
import com.tomtom.sdk.map.display.traffic.TrafficIncidentClickListener
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import kotlin.math.*

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    companion object {
        private const val LOCATION_REQUEST = 5001
    }

    private lateinit var map: TomTomMap
    private lateinit var locationManager: LocationManager
    private lateinit var tts: TextToSpeech

    private var currentLocation: Location? = null
    private var selectedStart: LatLng? = null
    private var selectedDestination: LatLng? = null

    private var currentRoute: RouteData? = null
    private var alternativeRoutes: List<RouteData> = emptyList()
    private var routeOptions: String = "fastest"
    private var avoidTolls = false
    private var avoidMotorways = false
    private var navigationRunning = false

    private val client = OkHttpClient()
    private val handler = Handler(Looper.getMainLooper())
    private var lastAnnouncedIndex = -1
    private var lastRerouteAt = 0L

    private lateinit var status: TextView
    private lateinit var nextInstruction: TextView
    private lateinit var etaText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var startInput: EditText
    private lateinit var destinationInput: EditText

    private data class LatLng(val lat: Double, val lon: Double)
    private data class Instruction(
        val point: LatLng,
        val message: String,
        val distance: Double
    )
    private data class RouteData(
        val points: List<LatLng>,
        val distanceMeters: Double,
        val travelSeconds: Int,
        val instructions: List<Instruction>
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        tts = TextToSpeech(this, this)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.map_fragment) as? MapFragment

        mapFragment?.getMapAsync { tomTomMap ->
            map = tomTomMap
            map.showTrafficFlow()
            map.showTrafficIncidents()
            status.text = "Real TomTom map • Live traffic ON"
            startLocation()
        }

        wireButtons()
        requestPermissionsIfNeeded()
    }

    private fun bindViews() {
        status = findViewById(R.id.status)
        nextInstruction = findViewById(R.id.nextInstruction)
        etaText = findViewById(R.id.etaText)
        progress = findViewById(R.id.progress)
        startInput = findViewById(R.id.startInput)
        destinationInput = findViewById(R.id.destinationInput)
    }

    private fun wireButtons() {
        findViewById<Button>(R.id.trafficButton).setOnClickListener {
            if (::map.isInitialized) {
                map.showTrafficFlow()
                map.showTrafficIncidents()
                status.text = "Live traffic ON"
            }
        }

        findViewById<Button>(R.id.gpsButton).setOnClickListener {
            val loc = currentLocation
            if (loc != null) {
                selectedStart = LatLng(loc.latitude, loc.longitude)
                startInput.setText("My location")
                status.text = "Start set to current GPS location"
            } else {
                startLocation()
                status.text = "Waiting for GPS fix…"
            }
        }

        findViewById<Button>(R.id.fastButton).setOnClickListener {
            routeOptions = "fastest"
            status.text = "Route mode: FASTEST"
        }

        findViewById<Button>(R.id.shortButton).setOnClickListener {
            routeOptions = "shortest"
            status.text = "Route mode: SHORTEST"
        }

        findViewById<Button>(R.id.tollsButton).setOnClickListener {
            avoidTolls = !avoidTolls
            status.text = if (avoidTolls) "Avoiding toll roads" else "Tolls allowed"
        }

        findViewById<Button>(R.id.motorwayButton).setOnClickListener {
            avoidMotorways = !avoidMotorways
            status.text = if (avoidMotorways) "Avoiding motorways" else "Motorways allowed"
        }

        findViewById<Button>(R.id.routeButton).setOnClickListener {
            calculateRoute()
        }

        findViewById<Button>(R.id.startNavigationButton).setOnClickListener {
            startNavigation()
        }

        findViewById<Button>(R.id.stopNavigationButton).setOnClickListener {
            stopNavigation()
        }
    }

    private fun requestPermissionsIfNeeded() {
        val permissions = buildList {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
            ) add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
            ) add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), LOCATION_REQUEST)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) return

        locationManager.requestLocationUpdates(
            LocationManager.GPS_PROVIDER,
            1000L,
            2f,
            locationListener
        )
        locationManager.requestLocationUpdates(
            LocationManager.NETWORK_PROVIDER,
            2000L,
            5f,
            locationListener
        )
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            currentLocation = location
            if (selectedStart == null) selectedStart = LatLng(location.latitude, location.longitude)

            if (navigationRunning) {
                updateNavigation(location)
            }
        }
    }

    private fun calculateRoute() {
        val key = BuildConfig.TOMTOM_API_KEY
        if (key.isBlank()) {
            status.text = "TomTom API key is missing"
            Toast.makeText(this, "Add TOMTOM_API_KEY to GitHub/local Gradle.", Toast.LENGTH_LONG).show()
            return
        }

        val destinationText = destinationInput.text.toString().trim()
        if (destinationText.isBlank()) {
            status.text = "Enter a destination"
            return
        }

        progress.visibility = View.VISIBLE
        status.text = "Searching destination…"

        val startText = startInput.text.toString().trim()
        if (startText.isBlank() || startText.equals("My location", true)) {
            val loc = currentLocation
            if (loc == null) {
                progress.visibility = View.GONE
                status.text = "Waiting for GPS location"
                return
            }
            selectedStart = LatLng(loc.latitude, loc.longitude)
            searchDestination(destinationText, selectedStart!!)
        } else {
            searchLocation(startText) { start ->
                selectedStart = start
                searchDestination(destinationText, start)
            }
        }
    }

    private fun searchDestination(query: String, start: LatLng) {
        searchLocation(query) { destination ->
            selectedDestination = destination
            requestRoute(start, destination)
        }
    }

    private fun searchLocation(query: String, callback: (LatLng) -> Unit) {
        val key = BuildConfig.TOMTOM_API_KEY
        val encoded = java.net.URLEncoder.encode(query, "UTF-8")
        val url = "https://api.tomtom.com/search/2/search/$encoded.json" +
                "?key=$key&limit=1&countrySet=LK&typeahead=false"

        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "Location search failed"
                    Toast.makeText(this@MainActivity, e.message ?: "Network error", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        runOnUiThread {
                            progress.visibility = View.GONE
                            status.text = "Search error ${it.code}"
                        }
                        return
                    }
                    val json = JSONObject(it.body?.string() ?: "{}")
                    val results = json.optJSONArray("results")
                    if (results == null || results.length() == 0) {
                        runOnUiThread {
                            progress.visibility = View.GONE
                            status.text = "Location not found"
                        }
                        return
                    }
                    val pos = results.getJSONObject(0)
                        .getJSONObject("position")
                    val point = LatLng(pos.getDouble("lat"), pos.getDouble("lon"))
                    runOnUiThread { callback(point) }
                }
            }
        })
    }

    private fun requestRoute(start: LatLng, destination: LatLng) {
        val key = BuildConfig.TOMTOM_API_KEY
        val avoid = buildList {
            if (avoidTolls) add("tollRoads")
            if (avoidMotorways) add("motorways")
        }.joinToString(",")

        val url = "https://api.tomtom.com/routing/1/calculateRoute/" +
                "${start.lat},${start.lon}:${destination.lat},${destination.lon}/json" +
                "?key=$key&traffic=true&routeType=$routeOptions" +
                "&maxAlternatives=2&instructionsType=text&language=en-GB" +
                if (avoid.isNotBlank()) "&avoid=$avoid" else ""

        status.text = "Calculating real traffic-aware route…"

        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "Route request failed"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        runOnUiThread {
                            progress.visibility = View.GONE
                            status.text = "Routing error ${it.code}"
                        }
                        return
                    }
                    val json = JSONObject(it.body?.string() ?: "{}")
                    val routes = json.optJSONArray("routes")
                    if (routes == null || routes.length() == 0) {
                        runOnUiThread {
                            progress.visibility = View.GONE
                            status.text = "No drivable route found"
                        }
                        return
                    }

                    val parsedRoutes = (0 until routes.length()).map { parseRoute(routes.getJSONObject(it)) }
                    val main = parsedRoutes.first()
                    runOnUiThread {
                        currentRoute = main
                        alternativeRoutes = parsedRoutes.drop(1)
                        drawRoutes(parsedRoutes)
                        progress.visibility = View.GONE
                        status.text = "REAL ROUTE • ${routes.length()} route option(s) • traffic-aware"
                        etaText.text = formatDuration(main.travelSeconds)
                        nextInstruction.text =
                            main.instructions.firstOrNull()?.message ?: "Route ready"
                    }
                }
            }
        })
    }

    private fun parseRoute(route: JSONObject): RouteData {
        val points = mutableListOf<LatLng>()
        val legs = route.optJSONArray("legs")
        if (legs != null) {
            for (i in 0 until legs.length()) {
                val leg = legs.getJSONObject(i)
                val pointsArray = leg.optJSONArray("points")
                if (pointsArray != null) {
                    for (j in 0 until pointsArray.length()) {
                        val p = pointsArray.getJSONObject(j)
                        points += LatLng(p.getDouble("latitude"), p.getDouble("longitude"))
                    }
                }
            }
        }

        val summary = route.optJSONObject("summary") ?: JSONObject()
        val distance = summary.optDouble("lengthInMeters", 0.0)
        val seconds = summary.optInt("travelTimeInSeconds", 0)

        val instructions = mutableListOf<Instruction>()
        val guidance = route.optJSONObject("guidance")
        val instructionArray = guidance?.optJSONArray("instructions")
        if (instructionArray != null) {
            for (i in 0 until instructionArray.length()) {
                val item = instructionArray.getJSONObject(i)
                val point = item.optJSONObject("point") ?: continue
                val message = item.optString("message")
                val travelTime = item.optInt("travelTimeInSeconds", 0)
                instructions += Instruction(
                    LatLng(point.getDouble("latitude"), point.getDouble("longitude")),
                    message,
                    item.optDouble("routeOffsetInMeters", distance)
                )
            }
        }
        return RouteData(points, distance, seconds, instructions)
    }

    private fun drawRoutes(routes: List<RouteData>) {
        if (!::map.isInitialized || routes.isEmpty()) return

        try {
            map.removeRoutes()
            routes.forEachIndexed { index, route ->
                if (route.points.size < 2) return@forEachIndexed
                val coords = route.points.map { GeoPoint(it.lat, it.lon) }
                val options = RouteOptions(coords).apply {
                    routeWidth = if (index == 0) 8.0 else 5.0
                    outlineWidth = if (index == 0) 2.5 else 1.5
                    color = if (index == 0) Color.rgb(0, 190, 255) else Color.rgb(120, 120, 135)
                    isFollowable = index == 0
                }
                map.addRoute(options)
            }
            map.zoomToRoutes(80)
        } catch (e: Exception) {
            status.text = "Map route draw error"
        }
    }

    private fun startNavigation() {
        val route = currentRoute
        if (route == null) {
            status.text = "Calculate a route first"
            return
        }
        navigationRunning = true
        lastAnnouncedIndex = -1
        startService(
            Intent(this, NavigationForegroundService::class.java)
                .putExtra("text", "DKxx Map navigation is active")
        )
        findViewById<Button>(R.id.startNavigationButton).visibility = View.GONE
        findViewById<Button>(R.id.stopNavigationButton).visibility = View.VISIBLE
        status.text = "NAVIGATION ACTIVE • GPS tracking ON"
        speak("Navigation started")
    }

    private fun stopNavigation() {
        navigationRunning = false
        stopService(Intent(this, NavigationForegroundService::class.java))
        findViewById<Button>(R.id.startNavigationButton).visibility = View.VISIBLE
        findViewById<Button>(R.id.stopNavigationButton).visibility = View.GONE
        status.text = "Navigation stopped"
        nextInstruction.text = "Choose a destination"
    }

    private fun updateNavigation(location: Location) {
        val route = currentRoute ?: return
        val nearest = nearestPoint(location.latitude, location.longitude, route.points)
        val distanceOffRoute = nearest.second

        if (distanceOffRoute > 45 && System.currentTimeMillis() - lastRerouteAt > 15_000) {
            lastRerouteAt = System.currentTimeMillis()
            status.text = "Off route • recalculating…"
            selectedStart = LatLng(location.latitude, location.longitude)
            selectedDestination?.let { requestRoute(selectedStart!!, it) }
            return
        }

        val next = route.instructions.firstOrNull { haversine(
            location.latitude, location.longitude, it.point.lat, it.point.lon
        ) > 25 }

        if (next != null) {
            val meters = haversine(location.latitude, location.longitude, next.point.lat, next.point.lon)
            nextInstruction.text = next.message
            status.text = "Navigation • ${meters.roundToInt()} m to next instruction"

            val idx = route.instructions.indexOf(next)
            if (idx != lastAnnouncedIndex && meters < 220) {
                lastAnnouncedIndex = idx
                speak(next.message)
            }
        } else {
            nextInstruction.text = "You have arrived"
            status.text = "ARRIVED"
            speak("You have arrived at your destination")
            stopNavigation()
        }
    }

    private fun nearestPoint(lat: Double, lon: Double, points: List<LatLng>): Pair<Int, Double> {
        var bestIndex = 0
        var bestDistance = Double.MAX_VALUE
        points.forEachIndexed { index, p ->
            val d = haversine(lat, lon, p.lat, p.lon)
            if (d < bestDistance) {
                bestDistance = d
                bestIndex = index
            }
        }
        return bestIndex to bestDistance
    }

    private fun haversine(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(bLat - aLat)
        val dLon = Math.toRadians(bLon - aLon)
        val x = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(aLat)) * cos(Math.toRadians(bLat)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(x))
    }

    private fun formatDuration(seconds: Int): String {
        if (seconds <= 0) return "—"
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        return if (h > 0) "${h}h ${m}m" else "${m} min"
    }

    private fun speak(text: String) {
        if (::tts.isInitialized && text.isNotBlank()) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "DKXX_${System.currentTimeMillis()}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.UK
            tts.setSpeechRate(0.95f)
        }
    }

    override fun onDestroy() {
        stopNavigation()
        if (::locationManager.isInitialized) {
            locationManager.removeUpdates(locationListener)
        }
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
