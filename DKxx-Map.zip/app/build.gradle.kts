import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val tomtomApiKey =
    providers.gradleProperty("tomtomApiKey")
        .orElse(providers.environmentVariable("TOMTOM_API_KEY"))
        .orElse("")
        .get()

android {
    namespace = "com.dkxx.map"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dkxx.map"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }

        val escapedKey = tomtomApiKey.replace("\\", "\\\\").replace("\"", "\\\"")
        buildConfigField("String", "TOMTOM_API_KEY", "\"$escapedKey\"")
        resValue("string", "tomtom_api_key", tomtomApiKey)
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("com.tomtom.sdk.maps:map-display:2.4.2")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.fragment:fragment-ktx:1.8.6")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
