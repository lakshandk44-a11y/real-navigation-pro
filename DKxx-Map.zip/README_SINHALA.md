# DKxx Map — Real TomTom Map Android App

මේ project එක demo/code-display screen එකක් නෙමෙයි. TomTom Maps SDK මගින් real map එකක් පෙන්වයි.

## තියෙන දේ

- Real TomTom map
- GPS location
- Start + destination search
- Real TomTom Search API
- Traffic-aware TomTom routing
- Fastest / Shortest
- Avoid toll roads
- Avoid motorways
- Up to 2 alternative route requests and visual display of returned alternatives
- Real route drawn on map
- Live traffic flow + incidents
- Animated map camera when route is fitted
- Start / stop navigation
- GPS progress
- Off-route detection + automatic route recalculation
- Turn instruction text
- Android Text-to-Speech voice guidance
- Foreground navigation notification
- App name: DKxx Map

## IMPORTANT: API key

Real API key එක project files වලට hard-code කරලා නැහැ.

### GitHub Actions

Repository එකේ:

Settings → Secrets and variables → Actions → New repository secret

Name:
TOMTOM_API_KEY

Value:
ඔයාගේ TomTom API key

ඊට පස්සේ Actions → Build Android APK → Run workflow.

### Local build

Environment variable:
TOMTOM_API_KEY=YOUR_KEY

හෝ:

gradle assembleDebug -PtomtomApiKey=YOUR_KEY

## Security

API key එක GitHub code එකට commit කරන්න එපා.

ඔයා chat එකට කලින් paste කරපු key එක exposed වෙලා තියෙන නිසා production use එකට ඒ key එක TomTom dashboard එකෙන් revoke/regenerate කරලා අලුත් key එක GitHub Secret එකට දාන්න.

## Note about "all roads"

Map එකේ TomTom road network එක පෙන්වයි. Route calculation එක main route එක සහ TomTom API එකෙන් ලබාගත හැකි alternative routes පෙන්වීමට architecture එක සකස් කරලා තියෙනවා. "ලෝකයේ/area එකේ තියෙන හැම possible route එකම එකවර highlight කිරීම" routing API එකෙන් guarantee කරන දෙයක් නෙමෙයි.

## Build requirements

TomTom Maps and Navigation SDK docs අනුව current Android setup එක API 35 compile SDK සහ Android 8+ minimum SDK භාවිතා කරයි.
