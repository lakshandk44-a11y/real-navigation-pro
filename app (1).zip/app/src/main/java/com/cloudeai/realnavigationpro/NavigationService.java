package com.cloudeai.realnavigationpro;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import androidx.core.app.NotificationCompat;
import com.google.android.gms.location.*;

public class NavigationService extends Service {
    public static final String CH="navigation";
    private FusedLocationProviderClient fused;
    private LocationCallback callback;

    @Override public void onCreate(){
        super.onCreate();
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CH,"Navigation",NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
        Intent stop=new Intent(this,MainActivity.class).setAction("STOP_NAV");
        PendingIntent pi=PendingIntent.getActivity(this,0,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new NotificationCompat.Builder(this,CH)
            .setContentTitle("Real Navigation Pro")
            .setContentText("Live navigation is running")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pi).setOngoing(true).build();
        startForeground(42,n);

        fused=LocationServices.getFusedLocationProviderClient(this);
        callback=new LocationCallback(){
            @Override public void onLocationResult(LocationResult result){
                if(result==null)return;
                android.location.Location loc=result.getLastLocation();
                if(loc==null)return;
                Intent i=new Intent("REAL_NAV_LOCATION");
                i.setPackage(getPackageName());
                i.putExtra("lat",loc.getLatitude()); i.putExtra("lon",loc.getLongitude());
                i.putExtra("speed",loc.getSpeed()); i.putExtra("bearing",loc.getBearing());
                i.putExtra("accuracy",loc.getAccuracy());
                sendBroadcast(i);
            }
        };
        requestUpdates();
    }

    private void requestUpdates(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return;
        LocationRequest req=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1500)
            .setMinUpdateIntervalMillis(800).setMinUpdateDistanceMeters(2).setWaitForAccurateLocation(false).build();
        fused.requestLocationUpdates(req,callback,Looper.getMainLooper());
    }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){if(fused!=null&&callback!=null)fused.removeLocationUpdates(callback);super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
