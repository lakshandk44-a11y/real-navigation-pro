// Android build note: set API_BASE to your deployed backend URL.
// Example: https://your-domain.example/api
// The APK intentionally does NOT embed the TomTom secret key.
const API_BASE = localStorage.getItem('apiBase') || '';
function nativeSpeak(t){ if(window.NativeNav && NativeNav.speak) NativeNav.speak(String(t)); else if("speechSynthesis" in window) speechSynthesis.speak(new SpeechSynthesisUtterance(String(t))); }
function nativeNav(on){ if(window.NativeNav){ if(on && NativeNav.startForeground) NativeNav.startForeground(); if(!on && NativeNav.stopForeground) NativeNav.stopForeground(); } }
const $=id=>document.getElementById(id);
const S={map:null,d:null,a:null,traffic:false,route:null,routeIndex:0,nav:false,gps:null,graph:null,nodes:null,res:{}};
S.map=L.map("mainMap").setView([7.8731,80.7718],8);
S.d=L.map("dMap").setView([7.8731,80.7718],8);
S.a=L.map("aMap").setView([7.8731,80.7718],8);
for(const m of [S.map,S.d,S.a])L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap contributors"}).addTo(m);

function stat(t,c=""){ $("status").textContent=t;$("status").className="status "+c }
function hav(a,b){const R=6371000,p=a.lat*Math.PI/180,q=b.lat*Math.PI/180,dp=(b.lat-a.lat)*Math.PI/180,dl=(b.lon-a.lon)*Math.PI/180,x=Math.sin(dp/2)**2+Math.cos(p)*Math.cos(q)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x))}
function km(m){return m>=1000?(m/1000).toFixed(1)+" km":Math.round(m)+" m"}
function time(s){let m=Math.round(s/60);return m<60?m+" min":Math.floor(m/60)+"h "+m%60+"m"}
function escapeHtml(x){return String(x??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

async function geocode(q){const r=await fetch(API_BASE+"/api/geocode?q="+encodeURIComponent(q));const d=await r.json();if(!r.ok)throw Error(d.error||"Geocode failed");const x=d.results?.[0];if(!x)throw Error("Place not found");return{lat:x.position.lat,lon:x.position.lon,name:x.address?.freeformAddress||x.address?.municipality||q}}
async function route(o,d,opts={}){const q=new URLSearchParams({origin:`${o.lat},${o.lon}`,dest:`${d.lat},${d.lon}`,traffic:String(opts.traffic!==false),routeType:opts.type||"fastest",maxAlternatives:"2"});if(opts.avoid)q.set("avoid",opts.avoid);const r=await fetch(API_BASE+"/api/route?"+q);const x=await r.json();if(!r.ok)throw Error(x.error?.description||x.error||"Routing failed");return x}
function routePoints(r){return (r.legs||[]).flatMap(l=>l.points||[]).map(p=>[p.latitude,p.longitude])}
function showRoutes(data){$("alts").innerHTML="";data.routes.forEach((r,i)=>{let e=document.createElement("div");e.className="alt"+(i===0?" active":"");e.innerHTML=`<b>${km(r.summary.lengthInMeters)}</b><small>${time(r.summary.travelTimeInSeconds)} · ${r.summary.trafficDelayInSeconds?Math.round(r.summary.trafficDelayInSeconds/60)+" min traffic delay":"low delay"}</small>`;e.onclick=()=>selectRoute(i);$("alts").appendChild(e)})}
function selectRoute(i){S.routeIndex=i;document.querySelectorAll(".alt").forEach((e,j)=>e.classList.toggle("active",i===j));const r=S.route.routes[i];if(S.mainLine)S.map.removeLayer(S.mainLine);S.mainLine=L.polyline(routePoints(r),{color:"#6dff9c",weight:6}).addTo(S.map);S.map.fitBounds(S.mainLine.getBounds(),{padding:[20,20]});$("eta").textContent=time(r.summary.travelTimeInSeconds);$("dist").textContent=km(r.summary.lengthInMeters);renderSteps(r)}
function renderSteps(r){const steps=r.legs.flatMap(l=>l.guidance?.instructions||[]);$("steps").innerHTML=steps.map((s,i)=>{const msg=s.message||s.instructionType||"Continue";return `<div class="step"><div class="num">${i+1}</div><div><b>${escapeHtml(msg)}</b><small>${escapeHtml(s.street||"")}</small></div><strong>${s.routeOffsetInMeters?km(s.routeOffsetInMeters):""}</strong></div>`}).join("");$("next").textContent=steps[0]?.message||"Continue";S.steps=steps;if(S.nav)nativeSpeak($("next").textContent)}
function addTraffic(){if(S.traffic)return;S.traffic=true;S.trafficLayer=L.tileLayer(API_BASE+"/traffic/relative-delay/{z}/{x}/{y}.png",{opacity:.8,maxZoom:19,attribution:"TomTom Traffic"}).addTo(S.map);$("trafficText").textContent="Live TomTom traffic overlay enabled";$("traffic").textContent="🚦 ON";fetchIncidents()}
async function fetchIncidents(){if(!S.mainLine)return;try{const b=S.mainLine.getBounds(),bbox=[b.getWest(),b.getSouth(),b.getEast(),b.getNorth()].join(",");const r=await fetch(API_BASE+"/api/incidents?bbox="+encodeURIComponent(bbox));const d=await r.json();(d.incidents||d.results||[]).forEach(x=>{const g=x.geometry?.coordinates;const p=x.properties||x.incidentDetails?.properties;if(Array.isArray(g)&&typeof g[0]==="number")L.circleMarker([g[1],g[0]],{radius:5,color:"#ff5d57",fillOpacity:.85}).bindPopup(`<b>Traffic incident</b><br>${escapeHtml(p?.description||p?.roadName||"Reported incident")}`).addTo(S.map)})}catch(e){console.warn(e)}}
function startGPS(){if(!navigator.geolocation)return stat("GPS unavailable","err");if(S.gps){navigator.geolocation.clearWatch(S.gps);S.gps=null;$("gps").textContent="◎ GPS";return}S.gps=navigator.geolocation.watchPosition(p=>{const ll=[p.coords.latitude,p.coords.longitude];if(!S.marker)S.marker=L.circleMarker(ll,{radius:8,color:"#5eb7ff",fillColor:"#5eb7ff",fillOpacity:1}).addTo(S.map);else S.marker.setLatLng(ll);$("gps").textContent="◎ LIVE";if(S.nav&&S.route){const pts=routePoints(S.route.routes[S.routeIndex]);let best=1e9,idx=0;pts.forEach((x,i)=>{const d=hav({lat:x[0],lon:x[1]},{lat:ll[0],lon:ll[1]});if(d<best){best=d;idx=i}});if(best<80){}},e=>stat("GPS: "+e.message,"err"),{enableHighAccuracy:true,maximumAge:2000,timeout:10000})}
function buildGraph(osm){const n=new Map();osm.elements.filter(x=>x.type==="node"&&x.lat!=null).forEach(x=>n.set(x.id,{...x,adj:[]}));osm.elements.filter(x=>x.type==="way"&&x.nodes).forEach(w=>{const one=w.tags?.oneway==="yes"||w.tags?.junction==="roundabout";for(let i=0;i<w.nodes.length-1;i++){let a=n.get(w.nodes[i]),b=n.get(w.nodes[i+1]);if(!a||!b)continue;let d=hav(a,b);a.adj.push({to:b.id,w:d});if(!one)b.adj.push({to:a.id,w:d})}});return new Map([...n].filter(([,x])=>x.adj.length))}
function nearest(n,p){let z,bd=1e30;for(const x of n.values()){let d=hav(x,p);if(d<bd){bd=d;z=x}}return z}
function push(h,x){h.push(x);let i=h.length-1;while(i){let p=(i-1)>>1;if(h[p].f<=h[i].f)break;[h[p],h[i]]=[h[i],h[p]];i=p}}
function pop(h){if(!h.length)return null;let t=h[0],x=h.pop();if(h.length){h[0]=x;let i=0;for(;;){let l=i*2+1,r=l+1,b=i;if(l<h.length&&h[l].f<h[b].f)b=l;if(r<h.length&&h[r].f<h[b].f)b=r;if(b===i)break;[h[i],h[b]]=[h[b],h[i]];i=b}}return t}
function search(s,g,aStar){let dist=new Map([[s,0]]),prev=new Map(),open=[],done=new Set(),vis=[];push(open,{id:s,f:0});while(open.length){let u=pop(open).id;if(done.has(u))continue;done.add(u);vis.push(u);if(u===g)break;for(let e of S.nodes.get(u).adj){let nd=dist.get(u)+e.w;if(nd<(dist.get(e.to)??1e30)){dist.set(e.to,nd);prev.set(e.to,u);push(open,{id:e.to,f:nd+(aStar?hav(S.nodes.get(e.to),S.nodes.get(g)):0)})}}}let route=[],x=g;while(x!==undefined){route.push(x);if(x===s)break;x=prev.get(x)}return{vis,route:route.reverse(),distance:dist.get(g)}}
async function algorithmCompare(o,d){const minLat=Math.min(o.lat,d.lat)-.02,maxLat=Math.max(o.lat,d.lat)+.02,minLon=Math.min(o.lon,d.lon)-.02,maxLon=Math.max(o.lon,d.lon)+.02;if(Math.max(maxLat-minLat,maxLon-minLon)>.45)throw Error("Choose closer places for the visual Dijkstra/A* graph.");const q=`[out:json][timeout:45];way["highway"~"motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link"](${minLat},${minLon},${maxLat},${maxLon});out body;>;out skel qt;`;let r=await fetch("https://overpass-api.de/api/interpreter",{method:"POST",body:q});if(!r.ok)throw Error("OSM graph unavailable");S.nodes=buildGraph(await r.json());let a=nearest(S.nodes,o),b=nearest(S.nodes,d);S.res.d=search(a.id,b.id,false);S.res.a=search(a.id,b.id,true);$("dv").textContent=S.res.d.vis.length.toLocaleString();$("av").textContent=S.res.a.vis.length.toLocaleString();$("rd").textContent=km(S.res.d.distance);$("save").textContent=Math.max(0,Math.round((1-S.res.a.vis.length/S.res.d.vis.length)*100))+"%";drawAlgo(S.d,S.res.d,"#a37cff");drawAlgo(S.a,S.res.a,"#6dff9c")}
function drawAlgo(m,r,c){m.eachLayer(x=>{if(x instanceof L.Polyline||x instanceof L.CircleMarker)m.removeLayer(x)});let n=S.nodes;r.vis.forEach(id=>{let x=n.get(id);L.circleMarker([x.lat,x.lon],{radius:2,color:c,stroke:false,fillOpacity:.4}).addTo(m)});L.polyline(r.route.map(id=>[n.get(id).lat,n.get(id).lon]),{color:"#6dff9c",weight:5}).addTo(m);m.fitBounds(L.latLngBounds(r.route.map(id=>[n.get(id).lat,n.get(id).lon])),{padding:[15,15]})}
$("go").onclick=async()=>{try{$("go").disabled=true;stat("Geocoding with TomTom…");let o=await geocode($("from").value),d=await geocode($("to").value);S.origin=o;S.dest=d;stat("Calculating traffic-aware routes…");S.route=await route(o,d,{type:document.querySelector(".routeMode.active").dataset.route});showRoutes(S.route);selectRoute(0);$("title").textContent=`${o.name} → ${d.name}`;stat("Traffic-aware route loaded. Building Dijkstra/A* comparison…","good");await algorithmCompare(o,d);stat("Complete: real road graph + TomTom traffic-aware route + alternatives.","good")}catch(e){stat(e.message,"err")}finally{$("go").disabled=false}};
$("swap").onclick=()=>[$("from").value,$("to").value]=[$("to").value,$("from").value];
$("traffic").onclick=()=>{S.traffic?null:addTraffic()};
$("gps").onclick=startGPS;
$("startNav").onclick=()=>{if(!S.route)return stat("Calculate a route first","err");S.nav=!S.nav;$("startNav").textContent=S.nav?"STOP NAVIGATION":"START NAVIGATION";nativeNav(S.nav);if(S.nav){startGPS();nativeSpeak($("next").textContent)}};
$("reset").onclick=()=>location.reload();
document.querySelectorAll(".routeMode").forEach(b=>b.onclick=()=>{document.querySelectorAll(".routeMode").forEach(x=>x.classList.remove("active"));b.classList.add("active")});
document.querySelectorAll("[data-avoid]").forEach(b=>b.onclick=async()=>{if(!S.origin)return stat("Calculate a route first","err");try{S.route=await route(S.origin,S.dest,{type:"fastest",avoid:b.dataset.avoid});showRoutes(S.route);selectRoute(0);stat("Avoidance route calculated.","good")}catch(e){stat(e.message,"err")}});
$("waypoint").onclick=()=>alert("Waypoint UI is prepared for the next routing extension. TomTom supports intermediate waypoints; add them before calculating a route.");


window.onNativeLocation = function(lat,lon,speed,bearing,accuracy){
  const p={lat,lon};
  if(!S.marker) S.marker=L.circleMarker([lat,lon],{radius:8,color:"#5eb7ff",fillColor:"#5eb7ff",fillOpacity:1}).addTo(S.map);
  else S.marker.setLatLng([lat,lon]);
  if(!S.nav || !S.route) return;
  const pts=routePoints(S.route.routes[S.routeIndex]||S.route.routes[0]);
  if(!pts.length) return;

  let best=Infinity,idx=0;
  pts.forEach((x,i)=>{const d=hav(p,{lat:x[0],lon:x[1]});if(d<best){best=d;idx=i}});
  const remain=pts.slice(idx).reduce((sum,x,i,a)=>i?sum+hav({lat:a[i-1][0],lon:a[i-1][1]},{lat:x[0],lon:x[1]}):0);

  if(remain<35){
    $("next").textContent="You have arrived.";
    speakOnce("ඔබ ගමනාන්තයට පැමිණියා.");
    nativeNav(false); S.nav=false; $("startNav").textContent="START NAVIGATION"; return;
  }

  if(best>80 && !S.reRouting && (!S.lastReroute || Date.now()-S.lastReroute>15000)){
    S.reRouting=true; S.lastReroute=Date.now();
    $("next").textContent="Recalculating route…";
    speakOnce("මාර්ගය වෙනස් වී ඇත. නැවත මාර්ගය සකස් කරමින්.");
    geocode(`${lat},${lon}`).then(o=>route(o,S.dest,{type:"fastest"})).then(x=>{
      S.route=x; showRoutes(x); selectRoute(0);
      speakOnce($("next").textContent);
    }).catch(()=>{}).finally(()=>S.reRouting=false);
    return;
  }

  // Smooth progress by looking a little ahead on the route.
  const look=Math.min(pts.length-1,idx+8);
  const target={lat:pts[look][0],lon:pts[look][1]};
  const roadBearing=bearingBetween(p,target);
  const delta=Math.abs(((roadBearing-(bearing||roadBearing)+540)%360)-180);
  if(delta>135) $("next").textContent="Follow the road and prepare to turn";
  else if(delta>70) $("next").textContent=turnText(bearing||roadBearing,roadBearing);
  else $("next").textContent=S.steps?.[Math.min(S.steps.length-1,Math.floor(idx/Math.max(1,pts.length)*S.steps.length))]?.message||"Continue straight";

  if(best<35) speakOnce($("next").textContent);
};


S.lastVoice="";
S.lastVoiceAt=0;
function speakOnce(msg){
  const now=Date.now();
  if(!msg || (msg===S.lastVoice && now-S.lastVoiceAt<12000)) return;
  S.lastVoice=msg; S.lastVoiceAt=now; nativeSpeak(msg);
}
function bearingBetween(a,b){
  const y=Math.sin((b.lon-a.lon)*Math.PI/180)*Math.cos(b.lat*Math.PI/180);
  const x=Math.cos(a.lat*Math.PI/180)*Math.sin(b.lat*Math.PI/180)-Math.sin(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.cos((b.lon-a.lon)*Math.PI/180);
  return (Math.atan2(y,x)*180/Math.PI+360)%360;
}
function turnText(prev,next){
  if(!prev||!next) return "";
  const d=((next-prev+540)%360)-180;
  if(Math.abs(d)<20) return "Continue straight";
  if(d>20&&d<70) return "Bear right";
  if(d>=70) return "Turn right";
  if(d<-20&&d>-70) return "Bear left";
  return "Turn left";
}
